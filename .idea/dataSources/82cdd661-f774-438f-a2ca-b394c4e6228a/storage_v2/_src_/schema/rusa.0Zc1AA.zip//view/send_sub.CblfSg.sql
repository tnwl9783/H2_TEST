create definer = root@localhost view send_sub as
select `rusa`.`tb_clt_urgent_nation`.`SEND_SSEQ`          AS `SEND_SSEQ`,
       `rusa`.`tb_clt_urgent_nation`.`SEND_MSEQ`          AS `SEND_MSEQ`,
       `rusa`.`tb_clt_urgent_nation`.`NATION_CODE`        AS `NATION_CODE`,
       `rusa`.`tb_clt_urgent_nation`.`COUNTRY_CALLBACKNO` AS `COUNTRY_CALLBACKNO`,
       `rusa`.`tb_clt_urgent_nation`.`SEND_FLAG`          AS `SEND_FLAG`,
       `rusa`.`tb_clt_urgent_nation`.`SEND_GSMCNT`        AS `SEND_GSMCNT`,
       `rusa`.`tb_clt_urgent_nation`.`SUCC_GSMCNT`        AS `SUCC_GSMCNT`,
       `rusa`.`tb_clt_urgent_nation`.`FAIL_GSMCNT`        AS `FAIL_GSMCNT`,
       `rusa`.`tb_clt_urgent_nation`.`EXPIRE_GSMCNT`      AS `EXPIRE_GSMCNT`,
       `rusa`.`tb_clt_urgent_nation`.`SEND_CDMACNT`       AS `SEND_CDMACNT`,
       `rusa`.`tb_clt_urgent_nation`.`SUCC_CDMACNT`       AS `SUCC_CDMACNT`,
       `rusa`.`tb_clt_urgent_nation`.`FAIL_CDMACNT`       AS `FAIL_CDMACNT`,
       `rusa`.`tb_clt_urgent_nation`.`EXPIRE_CDMACNT`     AS `EXPIRE_CDMACNT`,
       `rusa`.`tb_clt_urgent_nation`.`SENT_DT`            AS `SENT_DT`,
       `rusa`.`tb_clt_urgent_nation`.`REPORT_DT`          AS `REPORT_DT`,
       `rusa`.`tb_clt_urgent_nation`.`SEND_ENTRYDT`       AS `SEND_ENTRYDT`,
       `rusa`.`tb_clt_urgent_nation`.`SEND_UPDATEDT`      AS `SEND_UPDATEDT`,
       `rusa`.`tb_clt_urgent_nation`.`IDDPREFIX_GSM`      AS `IDDPREFIX_GSM`,
       `rusa`.`tb_clt_urgent_nation`.`IDDPREFIX_CDMA`     AS `IDDPREFIX_CDMA`
from `rusa`.`tb_clt_urgent_nation`
where `rusa`.`tb_clt_urgent_nation`.`CLIENT_YN` = 'Y';

-- comment on column send_sub.SEND_SSEQ not supported: 위급특보 국가 순번

-- comment on column send_sub.SEND_MSEQ not supported: 위급특보 순번

-- comment on column send_sub.NATION_CODE not supported: 국가 코드

-- comment on column send_sub.COUNTRY_CALLBACKNO not supported: 콜백 번호

-- comment on column send_sub.SEND_FLAG not supported: 전송 플래그

-- comment on column send_sub.SEND_GSMCNT not supported: 전송 GSM건수

-- comment on column send_sub.SUCC_GSMCNT not supported: 성공 GSM건수

-- comment on column send_sub.FAIL_GSMCNT not supported: 실패 GSM건수

-- comment on column send_sub.EXPIRE_GSMCNT not supported: 만료 GSM건수

-- comment on column send_sub.SEND_CDMACNT not supported: 전송 CDMA건수

-- comment on column send_sub.SUCC_CDMACNT not supported: 성공 CDMA건수

-- comment on column send_sub.FAIL_CDMACNT not supported: 실패 CDMA건수

-- comment on column send_sub.EXPIRE_CDMACNT not supported: 만료 CDMA건수

-- comment on column send_sub.SENT_DT not supported: 전송완료 시각

-- comment on column send_sub.REPORT_DT not supported: 리포트 수신시각 데이트

-- comment on column send_sub.SEND_ENTRYDT not supported: 전송 입력시각

-- comment on column send_sub.SEND_UPDATEDT not supported: 전송 수정시각

-- comment on column send_sub.IDDPREFIX_GSM not supported: 프레픽스 GSM

-- comment on column send_sub.IDDPREFIX_CDMA not supported: 프레픽스 CDMA

