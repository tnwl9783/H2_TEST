create definer = root@localhost view view_roamer as
select `c`.`NATION_CODE`   AS `NATION_CODE`,
       `c`.`COUNTRY_KNAME` AS `COUNTRY_KNAME`,
       `c`.`MOBILE_TYPE`   AS `MOBILE_TYPE`,
       count(0)            AS `ROAMER_CNT`,
       1                   AS `GBN`
from ((`rusa`.`gsmroamer_info` `a` join `rusa`.`gsm_info` `b`
       on (`b`.`COUNTRY_CODE` = `a`.`CC`)) join `rusa`.`country_info` `c` on (`c`.`NATION_CODE` = `b`.`NATION_CODE`))
where 1 = 1
group by `c`.`NATION_CODE`, `c`.`COUNTRY_KNAME`, `c`.`MOBILE_TYPE`
union all
select `c`.`NATION_CODE`   AS `NATION_CODE`,
       `c`.`COUNTRY_KNAME` AS `COUNTRY_KNAME`,
       `c`.`MOBILE_TYPE`   AS `MOBILE_TYPE`,
       count(0)            AS `ROAMER_CNT`,
       2                   AS `GBN`
from ((`rusa`.`cdmaroamer_info` `a` join `rusa`.`cdma_info` `b`
       on (`b`.`SID_CODE` = `a`.`SID`)) join `rusa`.`country_info` `c` on (`c`.`NATION_CODE` = `b`.`NATION_CODE`))
where 1 = 1
group by `c`.`NATION_CODE`, `c`.`COUNTRY_KNAME`, `c`.`MOBILE_TYPE`;

