create definer = root@localhost view send_master as
select `rusa`.`tb_clt_urgent`.`SEND_MSEQ`     AS `SEND_MSEQ`,
       `rusa`.`tb_clt_urgent`.`SEND_KMSG`     AS `SEND_KMSG`,
       `rusa`.`tb_clt_urgent`.`SEND_EMSG`     AS `SEND_EMSG`,
       `rusa`.`tb_clt_urgent`.`USER_ID`       AS `USER_ID`,
       `rusa`.`tb_clt_urgent`.`SEND_FLAG`     AS `SEND_FLAG`,
       `rusa`.`tb_clt_urgent`.`SEND_ENTRYDT`  AS `SEND_ENTRYDT`,
       `rusa`.`tb_clt_urgent`.`SEND_UPDATEDT` AS `SEND_UPDATEDT`,
       `rusa`.`tb_clt_urgent`.`SENT_DT`       AS `SENT_DT`,
       `rusa`.`tb_clt_urgent`.`REPORT_DT`     AS `REPORT_DT`
from `rusa`.`tb_clt_urgent`
where `rusa`.`tb_clt_urgent`.`CLIENT_YN` = 'Y';

-- comment on column send_master.SEND_MSEQ not supported: 위급특보 순번

-- comment on column send_master.SEND_KMSG not supported: 전송 한글메시지

-- comment on column send_master.SEND_EMSG not supported: 전송 영문메시지

-- comment on column send_master.USER_ID not supported: 사용자 ID

-- comment on column send_master.SEND_FLAG not supported: 전송 플래그

-- comment on column send_master.SEND_ENTRYDT not supported: 전송 입력시각

-- comment on column send_master.SEND_UPDATEDT not supported: 전송 수정시각

-- comment on column send_master.SENT_DT not supported: 전송완료 시각

-- comment on column send_master.REPORT_DT not supported: 리포트 수신시각 데이트

